function processResponse(response, cloudServiceAccountId, ldc, correlationId,step, requestorContext) {
	var cloudModelString = [];
	var snapshotResponse = global.JSON.parse(response);
	
	var snapshotInfo = {
		"cmdb_ci_storage_volume": {
			"validator": "default_storage_volume_validator",
			"validator_overrides": { },
			"identification": {
				"cmdb_ci_cloud_service_account": {"criterion": {"object_id": cloudServiceAccountId } },
				"cmdb_ci_aws_datacenter": {"criterion": {"object_id": ldc } },
				"cmdb_ci_storage_volume": {"criterion": { "object_id": snapshotResponse.volumeId } } 
			},
			"attributes": {
				"object_id": snapshotResponse.volumeId
			},
			"references" : {
				"cmdb_ci_storage_vol_snapshot": {
					"identification": {
						"cmdb_ci_cloud_service_account": {"criterion": {"object_id": cloudServiceAccountId } },
						"cmdb_ci_aws_datacenter": {"criterion": {"object_id": ldc } },
						"cmdb_ci_storage_vol_snapshot": {"criterion": { "object_id": snapshotResponse.snapshot } }
					},
					"attributes": {
						"name": snapshotResponse.snapshot,
						"object_id": snapshotResponse.snapshot,
						"state": "available"
					}
				}
			}
		}
	};

cloudModelString.push(snapshotInfo);
return global.JSON.stringify(cloudModelString);
}