//CAPI script for snapshot implementation.
CreateSnapshot();

function CreateSnapshot(){
	var location = this.parameters.get('Location');
	var desc = this.parameters.get('Description');
	var volumeId = this.parameters.get('volumeId');
	
	var awsAPI = new AWSCloudAPIBase(this.parameters, this.headers);
	awsAPI.service = 'ec2';
	awsAPI.apiVersion = '2016-11-15';
	var action = 'CreateSnapshot';
	var actionParams = {};
	actionParams['VolumeId'] = volumeId;
	actionParams['Description'] = desc;
	
	awsAPI.executeAction(action, actionParams);
	ms.log("executed AWS snapshot action");
	
	response = {};
	response.volumeId = volumeId;
	response.snapshot = desc;
	
	return response;
	
}