makeFolder();

function makeFolder(){	
	var bucketName = this.parameters.get('FolderName');
	var awsAPI = new AWSCloudAPIBase(this.parameters, this.headers);
	awsAPI.service = 's3';
	awsAPI.apiVersion = '2006-03-01';

	var endpoint = "https://s3.amazonaws.com/" + bucketName;
	var response = awsAPI.invoke(endpoint, "put", "");
	
	return response;
}