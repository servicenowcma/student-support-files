// get the parameter values needed to create a bucket on s3
var getParameters = function() {
 apiParameters =  {
   "FolderName": "your_bucket_name_goes_here",
   "Location": "us-east-1"
 };

 return apiParameters;
}

// setup the variables needed for the capi call
var interfaceName = "Cloud Blob Storage Interface";
var methodName = "CreateFolder";
var version = "1.1";
var endpoint = "";
var invokedBy = "capiScripts";
var apiParameters = getParameters();

// for aws
var providerName = "aws-s32";
var credentialId = "your_instances_sysid_foraws_credentials"; // sysid of credential needed to talk to aws

// Create CAPI API Executor Object
var capi = new sn_cloud_api.CAPIOrchestratorServiceScript();

// execute the api
var contextKey = capi.executeApi(providerName, version, credentialId, interfaceName, methodName, endpoint, new global.JSON().encode(apiParameters), invokedBy, "", "us-east-1");
gs.info("contextKey : " + contextKey);