function processResponse(response, cloudServiceAccountId, ldc, correlationId,step, requestorContext) {
    var cloudModelString = [];
	var s3Response = global.JSON.parse(response);
	var reqContext = global.JSON.parse(requestorContext);
	var s3BucketInfo = {
		"u_cmdb_ci_aws_s3_storage": {
			"identification": {
				"cmdb_ci_cloud_service_account": {
					"criterion": {
						"object_id": cloudServiceAccountId
					}
				},
				"cmdb_ci_aws_datacenter": {
					"criterion": {
						"object_id": ldc
					}
				},
				"u_cmdb_ci_aws_s3_storage": {
					"criterion": {
						"object_id": s3Response.bucketName
					}
				}
			},
			"attributes": {
				"object_id": s3Response.bucketName,
				"name": s3Response.bucketName // this sets name field in the CI 
				
			}
		}
	};
	
	if (!gs.nil(s3Response.tagValues)) {
		s3BucketInfo["u_cmdb_ci_aws_s3_storage"].tagValues = global.JSON.stringify(s3Response.tagValues);
	}
	
    
	
	
    cloudModelString.push(s3BucketInfo);
	return global.JSON.stringify(cloudModelString);
}
