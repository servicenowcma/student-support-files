#!/bin/bash

if which apt-get > /dev/null 2>&1
then
echo ****************Updating Repositories**********************
sudo apt-get update
echo ***************Installing Nginx Server Ubuntu *******************
sudo apt-get install nginx -y
sudo service nginx restart
else
echo **************Installing Nginx Server RedHat\Centos **********************
sudo yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo yum install nginx -y
sudo service nginx start
sudo service firewalld stop
fi